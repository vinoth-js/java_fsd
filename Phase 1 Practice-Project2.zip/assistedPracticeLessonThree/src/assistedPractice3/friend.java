package assistedPractice3;

import assistedPractice3.Sender;

public class friend extends Thread{
     String name;
	 String msg;
     Sender sender;
     
     public friend(String name, String msg, Sender sender) {
 		this.name = name;
 		this.msg = msg;
 		this.sender = sender;
 	 }
     
     public void run() {
    	 System.out.println(name+"wants to send a "+msg);
    	 
    	 //without synchronization
    	 //sender.send(msg);
    	 
    	 //with synchronization
    	 synchronized(sender){
    		 sender.send(msg);
    	 }
     }
     
}
