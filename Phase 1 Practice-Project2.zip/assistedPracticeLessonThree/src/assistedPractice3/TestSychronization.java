package assistedPractice3;

import assistedPractice3.Sender;

public class TestSychronization{

      
      public static void main(String args[]) {
    	  Sender sender=new Sender();  //target
    	  
    	  //passing target
    	  friend f1=new friend("xxx "," good morning!",sender);
    	  friend f2=new friend("yyy "," how is life",sender);
    	  
    	  f1.start();
    	  f2.start();
    	  
      }
}
