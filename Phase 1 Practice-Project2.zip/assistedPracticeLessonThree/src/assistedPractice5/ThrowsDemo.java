package assistedPractice5;

public class ThrowsDemo {
	//throws keyword is used to declare which exception can be thrown from a method
	void total() throws ArithmeticException{
        int a=10,b=0;
        int sum=a/b;
        System.out.println("sum is: "+sum);
    }
   public static void main(String args[]) {
     	
        ThrowsDemo td=new ThrowsDemo();
        
         try {
        	 td.total(); 
         }
         catch(Exception e) {
        	System.out.println("\nError: "+e.getMessage());
         }
        
    }
}
