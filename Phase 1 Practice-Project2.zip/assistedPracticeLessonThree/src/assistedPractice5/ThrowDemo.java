package assistedPractice5;

public class ThrowDemo {
	 public static void main(String args[]) {
     	
         int a=10,b=0;
         int sum=0;
         
         try {
        	 if(b==0) {
        		 //throw keyword is used to explicitly throw an exception within a method or block of code
        		 throw new ArithmeticException ("Can't divide the number by zero");
        	 }
        	 else {
        		 sum=a/b;
        	 } 
         }
         catch(Exception e) {
        	System.out.println("\nError: "+e.getMessage());
         }
        
   
    }
}
