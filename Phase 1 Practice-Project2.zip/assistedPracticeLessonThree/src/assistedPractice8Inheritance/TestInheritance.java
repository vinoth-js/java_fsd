package assistedPractice8Inheritance;

public class TestInheritance {
   public static void main(String args[]) {
	   Dog obj=new Dog();
	   obj.eat(); 
	   
	   Crocodile obj2=new Crocodile();
	   obj2.walk();
	   
	   BabyDog obj3=new BabyDog();
	   obj3.bark();
	   
   }
}
