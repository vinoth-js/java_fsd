package assistedPractice8Inheritance;

public class Animal {
	
	 
     void eat() {
    	 System.out.println("Eating...");
     }
     void walk() {
    	 System.out.println("Walking....");
     }
	
}
