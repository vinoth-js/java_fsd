package assistedPractice1;

public class ThreadDemo extends Thread {
	  
      public void run() {
    	  System.out.println("Thread is started");
      }
      
      public static void main(String[] args) {
    	  ThreadDemo td=new ThreadDemo();
    	  td.start();
    	  ThreadDemo td2=new ThreadDemo();
    	  td2.start();
      }
} 
