package assistedPracticeLessonFour;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class LIS {
	public static void main(String[] args) {
	    Random random=new Random();
		   Scanner sc=new Scanner(System.in);
		   System.out.println("Enter the list size: ");
		   int n=sc.nextInt();
		   int array[]=new int[n];
		for(int i=0;i<n;i++) {
				 array[i]=random.nextInt(100);  
		}
		System.out.print("List of random numbers ---> ");
		for (int i = 0; i < n; i++) {
			System.out.print(array[i]+" ");
	    }
		System.out.println();	
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		ArrayList<Integer> longestList = new ArrayList<Integer>();
		int currentMax;
		int highestCount = 0;
		for(int i = 0; i < array.length;i++)
		{
			currentMax = Integer.MIN_VALUE;
			for(int j = i;j < array.length; j++)
			{
				if(array[j] > currentMax)
				{
					list.add(array[j]);
					currentMax = array[j];
				}
			}
			
			
			if(highestCount < list.size())
			{
				highestCount = list.size();
				longestList = new ArrayList<Integer>(list);
			}
			list.clear();
		}
		System.out.println();
		
		//Print list
		Iterator<Integer> itr = longestList.iterator();
		System.out.println("The Longest subsequence");
		while(itr.hasNext())
		{
			System.out.print(itr.next() + " ");
		}
		System.out.println();
		System.out.println("Length of LIS: " + highestCount);
	}
	
}