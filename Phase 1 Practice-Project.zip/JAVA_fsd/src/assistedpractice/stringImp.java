package assistedpractice;

import java.util.Arrays;

public class stringImp {
    public static void main(String[] args) {
    	//String literal
    	String str="xxx";
    	System.out.println("String literal: "+str);
    	
    	//Create String using object
    	String str1=new String("xxx");
    	System.out.println("String object: "+str1);
    	
    	String[] stringArray= {"1","sfda","f","ff"};
    	System.out.println("Arrays to String: "+Arrays.toString(stringArray));
    	
    	//checking equals
    	System.out.println(str.equals(str1));
    	
    	//string reverse
    	String s="abcd";
    	String empty="";
    	for(int i=s.length()-1;i>=0;i--) {
    		empty+=s.charAt(i);
    	}
    	System.out.println(empty);
         
    	//replace
    	String another=s.replace('a', 'f');
    	System.out.println(another);
    	
    	//substring
    	String fString="one";
    	String sString="third";
    	
    	fString=fString+sString;
    	
    	sString=fString.substring(0,(fString.length()-sString.length()));
    	fString=fString.substring(sString.length());
    	
    	System.out.println("After swapping");
    	System.out.println(fString);
    	System.out.println(sString);
    	

    	
    	//StringBuilder
    	
    
    	String st="good";
    	StringBuilder sb=new StringBuilder(st);
    	sb.append("days");
    	
    	System.out.println("After append: "+sb);
    	
    	sb.delete(0,5 );
    	System.out.println("After delete: "+sb);
    	

    	//StringBuffer
    	
    
    	String s1="earth";
    	StringBuffer sbuff=new StringBuffer(s1);
    	sbuff.append(" is beautiful");
    	
    	System.out.println("After append: "+sbuff);
    	
    	sbuff.replace(0,5 , "ocean");
    	System.out.println("After replace: "+sbuff);
    	
    }
}
