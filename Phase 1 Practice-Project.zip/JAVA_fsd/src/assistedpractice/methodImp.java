package assistedpractice;

import java.util.Scanner;

public class methodImp {
     public void add(int num1,int num2) {
    	 int sum=num1+num2;
    	 System.out.println("method without return type but two parameters and Sum is: "+sum);
     }
     
     //method overloading
     public void add(int num1,int num2,int num3) {
    	 int sum=num1+num2+num3;
    	 System.out.println("same method name but three parameters and Sum is: "+sum);
     }

     
     public int returnMethod(int n1) {
    	 return n1;
     }
     
     public void emptyMethod() {
    	 System.out.println("method without return type and without parameter");
     }
     public String stringMethod(String name) {
    	 return name;
     }
     
     
     int value=200;
     void change(int value) {
    	 value=value+50;
     }
     
     
     public static void main(String args[]) {
    	 methodImp obj=new methodImp();
    	 Scanner sc=new Scanner(System.in);
    	 
    	 
    	 obj.add(5,2);
    	 
    	 obj.add(5, 4, 3);
    	 
    	 obj.emptyMethod();
    	 
    	 
    	 int n1=4;
    	 System.out.println("method with return and parameter "+obj.returnMethod(n1));
    	 
    	 String name="xxx";
    	 System.out.println("method with return String type with one parameter "+obj.stringMethod(name));
    	 
    	 
    	 //call by value 
    	 System.out.println("Before change of value "+obj.value);
    	 obj.change(500);
    	 System.out.println("After change of value "+obj.value);
    	 
    	 
     } 
}
