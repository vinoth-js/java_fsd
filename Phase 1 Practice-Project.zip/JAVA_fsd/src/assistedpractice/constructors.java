package assistedpractice;

public class constructors {
	 //default constructors
     int i;
     public constructors() {
   	  i=5;
   	  System.out.println("Default constructor is called"); 
     }  
     
     
   //parameterized constructor
     private int phoneNumber;
     private String name;
     private String mailId;
     
     public constructors(int phoneNumber, String name, String mailId) {
		this.phoneNumber = phoneNumber;
		this.name = name;
		this.mailId = mailId;
     }
     
     void display() {
    	 System.out.println("Parameterized constructor is called"); 
    	 System.out.println("Name: "+this.name+" PhoneNumber: "+this.phoneNumber+" MailId: "+this.mailId);
     }
    
     public static void main(String args[]) {
    	 constructors obj=new constructors();
    	 System.out.println("value of i: "+obj.i);
    	 
    	 constructors obj1=new constructors(765,"xxx","ll");
    	 obj1.display();
    	
     }
    
}
