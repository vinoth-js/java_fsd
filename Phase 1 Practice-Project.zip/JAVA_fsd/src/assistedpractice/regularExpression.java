package assistedpractice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;
import java.util.regex.*;

public class regularExpression {
	
	public static boolean isValid(String emailId) {
		String regex= "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
		Pattern pattern=Pattern.compile(regex);
		if(emailId==null) {
		    return false;
		}
		return pattern.matcher(emailId).matches();
	}
	public static void main(String args[]) {
		
	   String pattern="[our world is beautiful]";
	   String check="is";
       Pattern p=Pattern.compile(pattern);
       
       Matcher c=p.matcher(check);
       
       while(c.find())
   		   System.out.println("Found the text "+c.group()+" starting at index "+c.start()+" ending at index "+c.end());
          
           
       //another method
       System.out.println(Pattern.matches("ms.","msn"));  
       
       //email validation
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the emailId: ");
       String emailId;
       emailId=sc.next(); 
       boolean result=isValid(emailId);
       if(result==true) {
    	   System.out.println("Entered emailId is valid");
       }
       else {
    	   System.out.println("Entered emailId is not valid");
       }
    	    
}
}
