package assistedpractice;

public class access1 {
	private void privateDisplay() {
		System.out.println("calling private method");
	}
	static void defaultDisplay() {
		System.out.println("calling default method");
	}
	protected static void protectedDisplay() {
		System.out.println("calling protected method");
	}
	public static void publicDisplay() {
		System.out.println("calling public method");
	}
	
    public static void main(String args[]) {
         access1 obj= new  access1();
    	 obj.privateDisplay();
    	 obj.defaultDisplay();
    	 obj.protectedDisplay();
    	 obj.publicDisplay();
    	 
    }
}
