package assistedpractice;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class mapExample {
      public static void main(String args[]) { 
    	  
    	  //HashMap
    	  Map<Integer,String> aj=new HashMap<Integer,String>();
    	  
    	  aj.put(0,"xxx");
    	  aj.put(1,"yyy");
    	  aj.put(2,"aaa");
    	  aj.put(3,"bbb");
    	  
    	  aj.remove(3);
    	  
    	  for(Map.Entry sd:aj.entrySet()) {
    		  System.out.println(sd.getKey()+" "+sd.getValue());
     	  }  
    	  
    	  //TreeMap
          TreeMap<Integer,String> mj=new TreeMap<Integer,String>();
    	  
    	  mj.put(0,"sd");
    	  mj.put(1,"fd");
    	  mj.put(2,"ed");
    	  mj.put(3,"cd");
    	  
    	  for(Map.Entry md:mj.entrySet()) {
    		  System.out.println(md.getKey()+" "+md.getValue());
     	  }  
    	  
    	  //HashTable
          Hashtable<Integer,String> tj=new Hashtable<Integer,String>();
    	  
    	  tj.put(0,"bg");
    	  tj.put(1,"fg");
    	  tj.put(2,"hg");
    	  tj.put(3,"tg");
    	  
    	  for(Map.Entry td:tj.entrySet()) {
    		  System.out.println(td.getKey()+" "+td.getValue());
     	  }  
    	  
          
      }
      
}
