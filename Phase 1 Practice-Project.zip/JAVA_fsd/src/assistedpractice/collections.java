package assistedpractice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.*;


public class collections {
      //ArrayList
	public static void main(String args[]) {
	 //ArrayList
	  ArrayList<String> aL=new ArrayList<String>();
	  aL.add("abc");
	  aL.add("def");
	  aL.add("ghi");
	  System.out.println("ArrayList Example-------------------------");
	  System.out.println("ArrayList: "+aL);	 
	  
	  aL.remove(2);
	 
	  Iterator<String> itr= aL.iterator();
	  while(itr.hasNext()) {
		System.out.println("Using Iterator: "+itr.next());
	  }
	  
	  //LinkedList
	  List<String> lL=new LinkedList<String>();
	  lL.add("xxx");
	  lL.add("yyy");
	  lL.add("zzz");
	  System.out.println("LinkedList Example-----------------------------");
	  for(int i=0;i<lL.size();i++) {
		  System.out.println("LinkedList: "+lL.get(i));	
	  }
	  
	  lL.remove(2);
	
	  Iterator<String> itr2= lL.iterator();
	  while(itr2.hasNext()) {
		System.out.println(itr2.next());
	  }
	  
	//Vector
	  Vector<String> vc=new Vector<String>();
	  vc.add("xxx");
	  vc.add("yyy");
	  vc.add("zzz");
	  System.out.println("Vector Example-----------------------------");
	  for(int i=0;i<vc.size();i++) {
		  System.out.println("Vector: "+vc.get(i));	
	  }
	  
	  vc.remove(2);
	
	  Iterator<String> it= vc.iterator();
	  while(it.hasNext()) {
		System.out.println(it.next());
	  }
	  
	  //Stack
	  Stack<String> sc=new Stack<String>();
	  sc.push("ooo");
	  sc.push("jjj");
	  sc.push("kkk");
	  sc.push("ppp");
	  
	  System.out.println("Stack Example--------------------------------");
	  Iterator<String> itr3= sc.iterator();
	  while(itr3.hasNext()) {
		System.out.println(itr3.next());
	  }
	  System.out.println("peek element: " +sc.peek());
	  System.out.println("after peek: "+sc);
	  sc.pop();
	  System.out.println("after pop: "+sc);
	  
	//Queue
	  PriorityQueue<String> qu=new PriorityQueue<String>();
	  qu.offer("hh");
	  qu.offer("kk");
	  qu.offer("mm");
	  qu.offer("nn");
	  
	  System.out.println("Queue Example--------------------------------");
	  Iterator<String> itr4= qu.iterator();
	  while(itr4.hasNext()) {
		System.out.println(itr4.next());
	  }
	 
	  System.out.println("peek element: " +qu.peek());
	  System.out.println("after peek: "+qu);
	  qu.poll();
	  System.out.println("after poll: "+qu);
	  
	//HashSet
	  HashSet<String> hs=new HashSet<String>();
	  hs.add("hdsf");
	  hs.add("yafdj");
	  hs.add("aaa");
	  System.out.println("HashSet Example-----------------------------");

	  System.out.println("HashSet: "+hs);	
	 
	  hs.remove("yafdj");
	  System.out.println(hs.contains("aaa"));
	
	  Iterator<String> itr5= hs.iterator();
	  while(itr5.hasNext()) {
		System.out.println(itr5.next());
	  }
	  
	//LinkedHashHset
	  LinkedHashSet<String> lHs= new LinkedHashSet<String>();
		
	  lHs.add("hdsf");
	  lHs.add("yafdj");
	  lHs.add("aaa");
	  System.out.println("LinkedHashSet Example-----------------------------");

	  System.out.println("LinkedHashList: "+lHs);	
	 
	  lHs.remove("yafdj");
	  System.out.println(lHs.contains("aaa"));
	  
	  //cannot add duplicate value
	  lHs.add("aaa");
	
	  Iterator<String> itr6= lHs.iterator();
	  while(itr6.hasNext()) {
		System.out.println(itr6.next());
	  }
	  
	//LinkedHashHset
	  TreeSet<String> ts= new TreeSet<String>();
		
	  ts.add("hdsf");
	  ts.add("yafdj");
	  ts.add("aaa");
	  System.out.println("TreeSet Example-----------------------------");

	  System.out.println("TreeSet: "+ts);	
	 
	  ts.remove("yafdj");
	  System.out.println(ts.contains("aaa"));
	  
	  Iterator<String> itr7= ts.iterator();
	  while(itr7.hasNext()) {
		System.out.println(itr7.next());
	  }
	  //we cannot add null in treeSet
	  
	  
    }
}
