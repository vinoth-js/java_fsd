package assistedpractice;

public class access2 {
	public static void main(String args[]) {
        access1 obj= new  access1();
        
        //Here private method cannot accessible. Because it is outside the class.
    	//obj.privateDisplay();
        
    	obj.defaultDisplay();
    	obj.protectedDisplay();
    	obj.publicDisplay();	 
    }
}
