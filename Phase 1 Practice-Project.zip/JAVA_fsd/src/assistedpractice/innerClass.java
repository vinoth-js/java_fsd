package assistedpractice;

public class innerClass {;
    
    private String msg="Outer class is accessible to inner class";
    
  
   
    public class iClass{
    	public void print() {
        	System.out.println(msg);
        }
    	
    }
    
    //local inner class
    void point() {
    	class inClass{
    		void show() {
    		System.out.println("local inner class");
    		}
    	}
    	inClass c=new inClass();
		c.show();
    }
    
    public static void main(String[]args) {
    	innerClass obj=new innerClass();
    		
        innerClass.iClass in=obj.new iClass();
        	
        in.print();
        
        obj.point();
        
    }
    	
}

