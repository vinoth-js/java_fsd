package assistedPracticeLessonFive;

import java.util.Random;

public class insertionSort {
	 public static void insertion(int arr[]) {
		 int i,j,currentValue;
		 for(i=1;i<arr.length;i++) {
			 currentValue=arr[i];
			 
			 j=i-1;
			 while(j>=0 && arr[j]>currentValue) {
				 arr[j+1]=arr[j];//right shift
			     j--;
			 }
			 arr[j+1]=currentValue;
		 }
		 for(i=0;i<arr.length;i++) {
  	         System.out.print(arr[i]+" ");
    	}
	 }
	
	
	 public static void main(String args[]) {
	    	int a[]= {2,34,5333,5,66,444};
	        insertion(a);
	    }
}
