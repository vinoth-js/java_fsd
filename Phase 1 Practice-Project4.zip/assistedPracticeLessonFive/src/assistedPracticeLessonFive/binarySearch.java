package assistedPracticeLessonFive;

public class binarySearch {
	public static int binarysearch(int arr[],int first,int last,int key) {
		//it'll useful only for sorted array it seems
	    while(first<=last) {
	        int mid=(first+last)/2;
	        if(key<arr[mid]) {
	        	last=mid-1;
	        }
	        else if(key>arr[mid]) {
	        	first=mid+1; 
	        }
	        else {
	        	return mid;
	        }
	    }
	    return -1;  
	}
    public static void main(String args[]) {
   	 int a[]= {10,20,30,40,50,60,70};
   	 int key=60;
   	 int first=0;
   	 int last=a.length-1;
   	 
   	 System.out.println(binarysearch(a,first,last,key));
   	 
    }
}
