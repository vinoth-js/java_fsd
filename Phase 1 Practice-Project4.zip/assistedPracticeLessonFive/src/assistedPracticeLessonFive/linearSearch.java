package assistedPracticeLessonFive;

public class linearSearch {
	
	 public int linearsearch(int arr[],int key) {
		 int i;
		 for(i=0;i<arr.length;i++) {
			 if(arr[i]==key) {
				 return i;
			 }
		 }
		 return -1;	 
	 }
	
     public static void main(String args[]) {
    	 int a[]= {1,2,5,6,7,34,12,30};
    	 int key=34;
    	 linearSearch obj=new linearSearch();
    	 
    	 System.out.println(obj.linearsearch(a,key));
    	 
     }
}
