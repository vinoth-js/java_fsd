package assistedPracticeLessonFive;

import java.util.Random;

public class selectionSort {
	public static void selection(int arr[]) {
		int n=arr.length;
		for(int i=0;i<n;i++) {
			int minValue=arr[i];
			int minIndex=i;
			for(int j=i;j<n;j++) {
				if(minValue>arr[j]) {
					minValue=arr[j];
					minIndex=j;
					
				}
			}
			if(minValue<arr[i]) {
				int temp=arr[i];
				arr[i]=arr[minIndex];
				arr[minIndex]=temp;
			}
		}
		for(int i=0;i<arr.length;i++) {
 	         System.out.print(arr[i]+" ");
   	    }
	}
	
	
	 public static void main(String args[]) {
//		 Random random=new Random();
//		 int[] a=new int[10];
//		 for(int i=0;i<a.length;i++) {
//			 a[i]=random.nextInt(50);
//		 }
	    	int a[]= {2,34,5333,5,66,444};
	        selection(a);
	    }
}
